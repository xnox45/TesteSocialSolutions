﻿using Dapper;
using Dapper.Contrib.Extensions;
using TesteTecnicoImobiliaria.Modelo.Interfaces;
using TesteTecnicoImobiliaria.Modelo.Interfaces.DAL;
using TesteTecnicoImobiliaria.Modelo.Models;
using TesteTecnicoImobiliaria.Modelo.ViewModels;

namespace TesteTecnicoImobiliaria.DAL
{
    internal class ClienteDAL : IClienteDAL
    {
        private readonly IContextDAL contexto;

        public ClienteDAL(IContextDAL contexto)
        {
            this.contexto = contexto;
        }

        public void AtualizarCliente(ClienteModel cliente)
        {
            using (var connection = contexto.CreateConnection())
            {
                connection.Update<ClienteModel>(cliente);
            }
        }

        public void CadastrarCliente(ClienteModel cliente)
        {
            using (var connection = contexto.CreateConnection())
            {
                connection.Insert<ClienteModel>(cliente);
            }
        }

        public void AtivarCliente(int id)
        {
            using (var connection = contexto.CreateConnection())
            {
                var query = "UPDATE CLIENTE SET FL_ATIVO = 1 WHERE CD_CLIENTE = @id";
                connection.Execute(query, new { id });
            }
        }

        public void DesativarCliente(int id)
        {
            using (var connection = contexto.CreateConnection())
            {
                var query = "UPDATE CLIENTE SET FL_ATIVO = 0 WHERE CD_CLIENTE = @id";
                connection.Execute(query, new { id });
            }
        }

        public List<ClienteModel> ListarClientes()
        {
            List<ClienteModel> clientes = new List<ClienteModel>();
            using (var connection = contexto.CreateConnection())
            {
                clientes = connection.GetAll<ClienteModel>().ToList();
            }

            return clientes;
        }

        public IEnumerable<ClienteModel> ListarCliente(FilterCliente filter)
        {
            using (var connection = contexto.CreateConnection())
            {
                var query = "SELECT CD_CLIENTE, NM_CLIENTE, DS_EMAIL, NR_CPF, NR_CNPJ, FL_ATIVO FROM CLIENTE WHERE 1=1 ";

                query = string.IsNullOrWhiteSpace(filter.CNPJ) ? query : query += "and NR_CNPJ = @CNPJ";
                query = string.IsNullOrWhiteSpace(filter.CPF) ? query : query += "and NR_CPF = @CPF";
                query = string.IsNullOrWhiteSpace(filter.Nome) ? query : query += "and NM_CLIENTE = @Nome";
                query = string.IsNullOrWhiteSpace(filter.Email) ? query : query += "and DS_EMAIL = @Email";

                var result = connection.Query<ClienteModel>(query, filter);

                return result;
            }
        }

        public ClienteModel SelecionarCliente(int id)
        {
            ClienteModel cliente;
            using (var connection = contexto.CreateConnection())
            {
                cliente = connection.Get<ClienteModel>(id);
            }

            return cliente;
        }
    }
}
