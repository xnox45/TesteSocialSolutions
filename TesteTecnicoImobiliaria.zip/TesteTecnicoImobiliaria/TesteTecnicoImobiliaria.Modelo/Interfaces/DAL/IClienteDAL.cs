﻿using TesteTecnicoImobiliaria.Modelo.Models;
using TesteTecnicoImobiliaria.Modelo.ViewModels;

namespace TesteTecnicoImobiliaria.Modelo.Interfaces
{
    public interface IClienteDAL
    {
        void CadastrarCliente(ClienteModel cliente);
        void AtualizarCliente(ClienteModel cliente);
        List<ClienteModel> ListarClientes();
        void DesativarCliente(int id);
        void AtivarCliente(int id);
        ClienteModel SelecionarCliente(int id);
        IEnumerable<ClienteModel> ListarCliente(FilterCliente filter);
    }
}
