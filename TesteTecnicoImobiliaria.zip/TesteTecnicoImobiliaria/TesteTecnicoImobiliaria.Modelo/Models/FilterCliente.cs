﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteTecnicoImobiliaria.Modelo.Models
{
    public class FilterCliente
    {
        public string? Nome { get; set; }
        public string? CPF { get; set; }
        public string? CNPJ { get; set; }
        public string? Email { get; set; }
    }
}
