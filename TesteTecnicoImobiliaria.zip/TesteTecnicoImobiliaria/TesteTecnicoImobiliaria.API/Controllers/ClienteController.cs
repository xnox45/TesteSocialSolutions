﻿using Microsoft.AspNetCore.Mvc;
using TesteTecnicoImobiliaria.Modelo.Interfaces.Regra;
using TesteTecnicoImobiliaria.Modelo.Models;
using TesteTecnicoImobiliaria.Modelo.ViewModels;

namespace TesteTecnicoImobiliaria.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly IRnCliente rnCliente;

        public ClienteController(IRnCliente rnCliente)
        {
            this.rnCliente = rnCliente;
        }

        // GET: api/<ClienteController>
        [HttpGet]
        public IEnumerable<ClienteViewModel> Get()
        {
            return rnCliente.ListarClientes();
        } 
        
        [HttpPost("List")]
        public IEnumerable<ClienteViewModel> List(FilterCliente filter)
        {
            return rnCliente.ListarClienteFilter(filter);
        }

        // GET api/<ClienteController>/5
        [HttpGet("{id}")]
        public ClienteViewModel Get(int id)
        {
            return rnCliente.SelecionarCliente(id);
        }

        // POST api/<ClienteController>
        [HttpPost]
        public IActionResult Post([FromBody] ClienteViewModel cliente)
        {
            try
            {
                rnCliente.SalvarCliente(cliente);

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        // POST api/<ClienteController>/Ativar/5
        [HttpPost]
        [Route("Ativar/{id}")]
        public void AtivarCliente(int id)
        {
            rnCliente.AtivarCliente(id);
        }

        // POST api/<ClienteController>/Desativar/5
        [HttpPost]
        [Route("Desativar/{id}")]
        public IActionResult DesativarCliente(int id)
        {
            try
            {
                rnCliente.DesativarCliente(id);

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
