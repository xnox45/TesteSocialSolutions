﻿using AutoMapper;
using System.Net.Http;
using System.Text.Json.Serialization;
using TesteTecnicoImobiliaria.Modelo.Interfaces;
using TesteTecnicoImobiliaria.Modelo.Interfaces.Regra;
using TesteTecnicoImobiliaria.Modelo.Models;
using TesteTecnicoImobiliaria.Modelo.ViewModels;
using Newtonsoft.Json;

namespace TesteTecnicoImobiliaria.Regra
{
    internal class RnImovel : IRnImovel
    {
        private readonly IMapper mapper;
        private readonly IImovelDAL imovelDAL;

        public RnImovel(IMapper mapper, IImovelDAL imovelDAL)
        {
            this.mapper = mapper;
            this.imovelDAL = imovelDAL;
        }

        public ImovelViewModel SelecionarImovel(int id)
        {
            ImovelModel ImovelModel = imovelDAL.SelecionarImovel(id);
            var Imovel = mapper.Map<ImovelViewModel>(ImovelModel);

            return Imovel;
        }

        public void AtivarImovel(int id)
        {
            imovelDAL.AtivarImovel(id);
        }

        public void DesativarImovel(int id)
        {
            imovelDAL.DesativarImovel(id);
        }

        public List<ImovelViewModel> ListarImoveis()
        {
            var retorno = new List<ImovelViewModel>();
            var Imovels = imovelDAL.ListarImoveis();
            retorno = mapper.Map<List<ImovelViewModel>>(Imovels);

            return retorno;
        }

        public void SalvarImovel(ImovelViewModel Imovel)
        {
            EnderecoViaCepModel endereco = ViaCep(Imovel.Cep).Result; 

            ImovelModel ImovelModel = mapper.Map<ImovelModel>(Imovel);

            //ImovelModel = mapper.Map<ImovelModel>(endereco); comentando para não remover os valores já setado

            if (Imovel.Id == 0)
            {
                imovelDAL.CadastrarImovel(ImovelModel);
            }
            else
            {
                imovelDAL.AtualizarImovel(ImovelModel);
            }
        }

        public List<ImovelModel> ListarImoveisPorCliente(int idCliente) => imovelDAL.ListarImoveisPorCliente(idCliente);

        public async Task<EnderecoViaCepModel> ViaCep(string cep)
        {
            HttpClient httpClient = new HttpClient()
            {
                BaseAddress = new Uri($@"https://viacep.com.br/ws/")
            };

            HttpResponseMessage response = await httpClient.GetAsync($"{cep}/json");

            if (response.IsSuccessStatusCode)
            {
                 return JsonConvert.DeserializeObject<EnderecoViaCepModel>(await response.Content.ReadAsStringAsync());
            }

            throw new Exception("Nenhum endereço encontrado");
        }
    }
}
