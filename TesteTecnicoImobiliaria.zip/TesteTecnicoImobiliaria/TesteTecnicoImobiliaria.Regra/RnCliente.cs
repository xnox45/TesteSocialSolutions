﻿using AutoMapper;
using TesteTecnicoImobiliaria.Modelo.Interfaces;
using TesteTecnicoImobiliaria.Modelo.Interfaces.Regra;
using TesteTecnicoImobiliaria.Modelo.Models;
using TesteTecnicoImobiliaria.Modelo.ViewModels;

namespace TesteTecnicoImobiliaria.Regra
{
    internal class RnCliente : IRnCliente
    {
        private readonly IMapper mapper;
        private readonly IClienteDAL clienteDAL;
        private readonly IRnImovel rnImovel;

        public RnCliente(IMapper mapper, IClienteDAL clienteDAL, IRnImovel rnImovel)
        {
            this.mapper = mapper;
            this.clienteDAL = clienteDAL;
            this.rnImovel = rnImovel;
        }

        public ClienteViewModel SelecionarCliente(int id)
        {
            ClienteModel clienteModel = clienteDAL.SelecionarCliente(id);
            var cliente = mapper.Map<ClienteViewModel>(clienteModel);

            return cliente;
        }

        public void AtivarCliente(int id)
        {
            clienteDAL.AtivarCliente(id);
        }

        public void DesativarCliente(int id)
        {
            var imovel = rnImovel.ListarImoveisPorCliente(id);

            if (imovel != null && imovel.Count > 0)
                throw new Exception("Não pode desativar pois tem imovel ativo no nome do cliente");

            clienteDAL.DesativarCliente(id);
        }

        public List<ClienteViewModel> ListarClientes()
        {
            var retorno = new List<ClienteViewModel>();
            var clientes = clienteDAL.ListarClientes();
            retorno = mapper.Map<List<ClienteViewModel>>(clientes);

            return retorno;
        }

        public void SalvarCliente(ClienteViewModel cliente)
        {
            ClienteModel clienteModel = mapper.Map<ClienteModel>(cliente);

            if (string.IsNullOrWhiteSpace(cliente.CNPJ) && string.IsNullOrWhiteSpace(cliente.CPF))
                throw new Exception("CPF ou CNPJ obrigatório");

            FilterCliente filter = new FilterCliente() { CPF = cliente.CPF, CNPJ = cliente.CNPJ};

            var clientes = ListarClienteFilter(filter);

            if (clientes != null && clientes.Count > 0)
                throw new Exception("Cpf ou Cnpj Já cadastrado");

            if (cliente.Id == 0)
            {
                clienteDAL.CadastrarCliente(clienteModel);
            }
            else
            {
                clienteDAL.AtualizarCliente(clienteModel);
            }
        }

        public List<ClienteViewModel> ListarClienteFilter(FilterCliente filter) => mapper.Map<List<ClienteViewModel>>(clienteDAL.ListarCliente(filter).ToList());
    }
}
